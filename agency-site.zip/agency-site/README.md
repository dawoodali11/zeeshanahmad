# Northstar Digital static website

A framework-free HTML, CSS, and JavaScript website ready for GitHub Pages.

## Before publishing
1. Replace every `https://www.yourdomain.com` occurrence with the final domain.
2. Replace `hello@yourdomain.com` in `contact/index.html` and `js/script.js`.
3. Rename the placeholder brand if required.
4. Upload the entire folder to the root of the GitHub Pages repository.

The contact form validates in the browser and opens the visitor's email app. It does not store or transmit submissions through a backend.
