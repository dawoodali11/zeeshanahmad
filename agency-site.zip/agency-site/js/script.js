(() => {
  const toggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.main-nav');
  const drops = document.querySelectorAll('.drop-toggle');
  toggle?.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    toggle.classList.toggle('active', open);
    toggle.setAttribute('aria-expanded', String(open));
    toggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
  });
  drops.forEach((button) => button.addEventListener('click', (event) => {
    event.stopPropagation();
    const item = button.closest('.has-dropdown');
    const open = item.classList.toggle('open');
    button.setAttribute('aria-expanded', String(open));
    document.querySelectorAll('.has-dropdown.open').forEach((other) => {
      if (other !== item) { other.classList.remove('open'); other.querySelector('.drop-toggle')?.setAttribute('aria-expanded', 'false'); }
    });
  }));
  document.addEventListener('click', (event) => {
    if (!event.target.closest('.has-dropdown')) document.querySelectorAll('.has-dropdown.open').forEach((item) => item.classList.remove('open'));
  });
  document.querySelectorAll('.main-nav a').forEach((link) => link.addEventListener('click', () => {
    nav?.classList.remove('open'); toggle?.classList.remove('active'); toggle?.setAttribute('aria-expanded', 'false');
  }));
  document.querySelectorAll('[data-year]').forEach((el) => el.textContent = new Date().getFullYear());
  const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (!reduced && 'IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries) => entries.forEach((entry) => {
      if (entry.isIntersecting) { entry.target.classList.add('visible'); observer.unobserve(entry.target); }
    }), { threshold: .12 });
    document.querySelectorAll('.reveal').forEach((el) => observer.observe(el));
  } else document.querySelectorAll('.reveal').forEach((el) => el.classList.add('visible'));
  const form = document.querySelector('[data-contact-form]');
  form?.addEventListener('submit', (event) => {
    event.preventDefault(); let valid = true;
    form.querySelectorAll('[required]').forEach((field) => {
      const wrap = field.closest('.field'); const message = wrap.querySelector('small');
      const bad = !field.value.trim() || (field.type === 'email' && !/^\S+@\S+\.\S+$/.test(field.value));
      wrap.classList.toggle('invalid', bad); message.textContent = bad ? `Please enter a valid ${field.name}.` : ''; if (bad) valid = false;
    });
    if (!valid) { form.querySelector('.invalid input, .invalid textarea')?.focus(); return; }
    const data = new FormData(form);
    const subject = encodeURIComponent(data.get('subject'));
    const body = encodeURIComponent(`Name: ${data.get('name')}\nEmail: ${data.get('email')}\n\n${data.get('message')}`);
    window.location.href = `mailto:hello@yourdomain.com?subject=${subject}&body=${body}`;
  });
})();
